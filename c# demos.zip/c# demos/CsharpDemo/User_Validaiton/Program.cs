﻿using System;

namespace Demo_HelloWorld
{
    internal class Program
    {
        class Demo 
        {}
        static void Main(string[] args)
        {
            Console.WriteLine("User, Please enter your name: ");
            string Name = Console.ReadLine();
            Console.WriteLine();


            Console.WriteLine("User, Please enter your age");
            int age = int.Parse(Console.ReadLine());
            Console.WriteLine();
            if (age <= 18)
            {
                Console.WriteLine("{0} you are below 18 years.", Name);
            }
            else
            {
                Console.WriteLine("{0} you are above 18 years.", Name);
            }
        }

           
            
        
    }
}

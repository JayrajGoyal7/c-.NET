﻿using System;

namespace Demo_HelloWorld
{
    internal class Program
    {
        static void Main(string[] args)   
        {
                System.Console.WriteLine("Hello World");
                System.Console.WriteLine("Different world");

                Console.WriteLine("Another world");

                Console.Write("Enter your name: ");
                string name = Console.ReadLine();

                Console.WriteLine("Enter your Age: ");
                int age = int.Parse( Console.ReadLine() );

                Console.WriteLine("Hi {0}, your age is {1}", name, age);
            }
        }
    }

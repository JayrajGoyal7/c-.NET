﻿using System;

namespace Demo_DataTypes
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int i = 10;
            bool b = true;
            char c = 'A';
            string s = "Hello World";
            long l = 20L;

            int j = int.MaxValue;
            Console.WriteLine("j = {0}, j");
            j = j + 1;
            Console.WriteLine(" Value of {0} is", j);
        }
    }
}

﻿using System;

    class DemoShapes
    {
        public float length, height, width, radius, breadth,sideA, sideB, side, breadthForTriangle;
        public void Rectangle()
        {
            // Area of Rectangle
            Console.WriteLine("Enter the Length for Rectangle");
            length = float.Parse(Console.ReadLine());
            Console.WriteLine("Enter the breadth for Rectangle");
            breadth = float.Parse(Console.ReadLine());
            Console.WriteLine("Area of rectangle is :{0}", length * breadth);

            //Perimeter for Rectangle
            Console.WriteLine("Perimeter for Rectangle is:{0}",2*(length + breadth));
            
        }
        public void Circle()
        {   
            // Area for Circle
            Console.WriteLine("Enter the Radius of the Circle");
            radius = float.Parse(Console.ReadLine());
            Console.WriteLine("Area of Circle is:{0}", 3.14 * radius * radius);

            // Perimeter for circle
            Console.WriteLine("Perimeter for Circle is:{0} ", 2 * 3.14 * radius);
        }
        public void Square()
        {
            // Area for square
            Console.WriteLine("Enter the side of a square");
            side = float.Parse(Console.ReadLine());
            Console.WriteLine("Area of Square is:{0}", side * side);

            // Perimeter for Square
            Console.WriteLine("Perimeter for Square is:{0}", 4*side);
        }
        public void Triangle()
        {
            // Area of Triangle
            Console.WriteLine("Enter the Breadth for Triangle ");
            breadthForTriangle = float.Parse(Console.ReadLine());
            Console.WriteLine("Enter the Height for Triangle ");
            height = float.Parse(Console.ReadLine());
            Console.WriteLine("Area of Triangle is:{0}", (breadthForTriangle * height) / 2);
            
            // Perimeter of Triangle
            Console.WriteLine("Enter 2 another side for obtaining perimeter: ");
            Console.WriteLine("Enter value for side A");
            sideA = float.Parse(Console.ReadLine());
            Console.WriteLine("Enter value for side B");
            sideB = float.Parse(Console.ReadLine());
            Console.WriteLine("Perimeter of Triangle is:{0}", sideA+sideB+breadthForTriangle);

        }


    }

    class Calculate : DemoShapes
    {
        
        static void Main(string[] args)
        {
            Console.WriteLine("Select the shape given below for getting area and perimeter");
            Console.WriteLine("1) Triangle");
            Console.WriteLine("2) Square");
            Console.WriteLine("3) Rectangle");
            Console.WriteLine("4) Circle");

            int number = int.Parse(Console.ReadLine());

            if (number == 1)
            {
                Console.WriteLine("You have selected triangle.");
                Calculate a =  new Calculate();
                a.Triangle();

            }
            else if (number == 2)
            {
                Console.WriteLine("You have selected Square.");
                Calculate a = new Calculate();
                a.Square();
            }
            else if (number == 3)
            {
                Console.WriteLine("You have selected Rectangle.");
                Calculate a = new Calculate();
                a.Rectangle();
            }
            else
            {
                Console.WriteLine("You have selected Circle.");
                Calculate a = new Calculate();
                a.Circle();
            }

        }





         
    }

